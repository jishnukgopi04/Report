package com.example.drawline.drawline;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.*;
import android.support.annotation.NonNull;
import android.util.AttributeSet;
import android.util.Log;
import android.view.*;

public class CustomLineView extends View {
    private static final float STROKE_WIDTH =5.0f;
    private static final int STROKE_COLOR=Color.BLUE;
    private final Paint mPaint;
    private float mStartX;
    private float mStartY;
    private float mEndX;
    private float mEndY;
    private boolean mStartStatus =false;
    private Path mPath;
    private float mLength;

    public CustomLineView(Context context) {
        this(context, null);
    }

    public CustomLineView(Context context, AttributeSet attrs) {
        super(context, attrs);
        mPaint = new Paint();
        mPaint.setStrokeWidth(STROKE_WIDTH);
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setColor(STROKE_COLOR);
    }
    public void init()
    {
        mPath = new Path();
        mPath.moveTo(mStartX, mStartY);
        mPath.lineTo(mEndX, mEndY);
        PathMeasure measure = new PathMeasure(mPath, false);
        mLength = measure.getLength();
        float[] intervals = new float[]{mLength, mLength};
        ObjectAnimator animator = ObjectAnimator.ofFloat(CustomLineView.this,"phase", 1.0f, 0.0f);
        animator.setDuration(300);
        animator.start();

    }
    public void setPhase(float phase)
    {
        Log.d("pathview","setPhase called with:" + String.valueOf(phase));
        mPaint.setPathEffect(createPathEffect(mLength, phase, 0.0f));
        invalidate();//will calll onDraw
    }
    private static PathEffect createPathEffect(float pathLength, float phase, float offset)
    {
        return new DashPathEffect(new float[] { pathLength, pathLength },
                Math.max(phase * pathLength, offset));
    }
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        mStartX=canvas.getWidth()/2;
        mStartY =canvas.getHeight()/2;
        if(mStartStatus) {
            canvas.drawPath(mPath, mPaint);
        }
    }
    @Override
    public boolean onTouchEvent(@NonNull MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                mStartStatus =true;
                mEndX = event.getX();
                mEndY = event.getY();
                init();
                invalidate();
                break;
            case MotionEvent.ACTION_MOVE:
                mStartStatus =true;
                mEndX = event.getX();
                mEndY = event.getY();
                init();
                invalidate();
                break;
            case MotionEvent.ACTION_UP:
                mStartStatus =true;
                mEndX = event.getX();
                mEndY = event.getY();
                init();
                invalidate();
                break;
        }
        return true;
    }
}